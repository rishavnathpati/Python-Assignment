str = input("Enter the sentence : ")
print("The original string is : ", str)
res = len(str.split())
print("The number of words in string are : ", res)
