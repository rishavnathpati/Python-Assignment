l = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
print(l, "\n", tuple(l))
