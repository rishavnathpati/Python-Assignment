word = "Python"
for i in range(len(word)):
    print(word[i])
